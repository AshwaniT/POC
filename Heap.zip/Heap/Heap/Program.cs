﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heap
{
    class Program
    {
        static void Main(string[] args)
        {
            var mh = new MinHeap(15);
            mh.Insert(5);
            mh.Insert(3);
            mh.Insert(17);
            mh.Insert(10);
            mh.Insert(84);
            mh.Insert(19);
            mh.Insert(6);
            mh.Insert(22);
            mh.Insert(9);
            mh.MinHeapify();
            mh.Print();
            Console.WriteLine("==========================Min value {0}========",mh.Remove());
            mh.Print();
            Console.Read();
        }
    }
}
