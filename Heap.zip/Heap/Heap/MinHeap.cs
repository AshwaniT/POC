﻿using System;

namespace Heap
{
    public class MinHeap
    {
        private int[] heap;
        private int MaxSize;
        private int size;
        private const int Front = 1;

        public MinHeap(int maxSize)
        {
            heap = new int[maxSize+1];
            this.MaxSize = maxSize;
            size = 0;
            heap[0] = int.MinValue;
        }

        public int LeftChild(int pos)
        {
            return 2*pos;
        }

        public int GetValue(int pos)
        {
            if (pos > size) return -1;
            return heap[pos];
        }

        public int RightChild(int pos)
        {
            return 2*pos + 1 ;
        }

        private bool Leaf(int pos)
        {
            return pos >= (size/2) && pos <= size;
        }

        private void Swap(int x, int y)
        {
            var temp = heap[x];
            heap[x] = heap[y];
            heap[y] = temp;
        }

        private void Heapify(int pos)
        {
            if (!Leaf(pos))
            {
                if (heap[pos] > heap[LeftChild(pos)] || heap[pos] > heap[RightChild(pos)])
                {
                    if (heap[LeftChild(pos)] < heap[RightChild(pos)])
                    {
                        Swap(pos,LeftChild(pos));
                        Heapify(LeftChild(pos));
                    }
                    else
                    {
                        Swap(pos, RightChild(pos));
                        Heapify(RightChild(pos));
                    }
                }
            }
        }

        private int Parent(int pos)
        {
            return pos/2;
        }
        public void Insert(int element)
        {
            //if(size>=MaxSize)
            //    throw  new ArgumentOutOfRangeException();
            heap[++size] = element;   
           
           
            var currentIndex = size;
            while (heap[currentIndex]<heap[Parent(currentIndex)])
            {
               Swap(currentIndex,Parent(currentIndex));
                currentIndex = Parent(currentIndex);

            }
        }

        public void MinHeapify()
        {
            for (var i=size/2; i >=1; i--)
            {
                Heapify(i);
            }
            
        }

        public int Remove()
        {
            var popped = heap[Front];
            heap[Front] = heap[--size];
            Heapify(Front);
            return popped;
        }

        public void Print()
        {
            for (int i = 1; i <= size / 2; i++)
            {
                if(!Leaf(i))
                Console.WriteLine("Element {0} has left child {1} and right child {2}",GetValue(i),GetValue(LeftChild(i)),GetValue(RightChild(i)));
            }
        }
}
}
