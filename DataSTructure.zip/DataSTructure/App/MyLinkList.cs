﻿
using System.Collections.Generic;

namespace App
{
    public class MyLinkList<T> : ICollection<T>
    {
        private Node<T> _headNode;
        private Node<T> _tailNode;
        public void Add(T item)
        {
            var node = new Node<T>(item);
            if (_headNode == null)
            {
                _headNode = node;
                _tailNode = node;
            }
            else
            {

                _tailNode.NextNode = node;
                _tailNode = node;
            }
            Count++;
        }

        public void Clear()
        {
            _headNode = null;
            _tailNode = null;
            Count = 0;
        }

        public bool Contains(T item)
        {
            var current = _headNode;
            while (current != null)
            {
                if (current.Value.Equals(item))
                {
                    return true;
                }
                current = current.NextNode;
            }
            return false;
        }

        public void CopyTo(T[] array, int arrayIndex)
        {
            throw new System.NotImplementedException();
        }

        public int Count
        {
            get;
            private set;
        }

        public bool IsReadOnly
        {
            get { throw new System.NotImplementedException(); }
        }

        public bool Remove(T item)
        {
            Node<T> previous = null;
            var current = _headNode;
            if (current == null)
            {
                Count--;
                return false;
            }
            while (current != null)
            {
                if (current.Value.Equals(item))
                {
                    if (previous != null)
                    {
                        previous.NextNode = current.NextNode;
                        if (previous.NextNode == null)
                        {
                            _tailNode = previous;
                        }
                    }
                    else
                    {
                        _headNode = _headNode.NextNode;
                        if (_headNode == null)
                        {
                            _tailNode = null;
                        }
                    }
                    return true;
                }
                previous = current;
                current = current.NextNode;
                Count--;

            }
            return false;
        }

        public IEnumerator<T> GetEnumerator()
        {
            var current = _headNode;
            while (current!=null)
            {
                yield return current.Value;
                current = current.NextNode;
            }

        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return ((IEnumerable<T>)this).GetEnumerator();
        }
    }
}
