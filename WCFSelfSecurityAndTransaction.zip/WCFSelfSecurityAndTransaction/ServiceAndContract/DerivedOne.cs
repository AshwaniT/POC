﻿
using System.Runtime.Serialization;

namespace ServiceAndContract
{
     [DataContract]
  public  class DerivedOne: BaseOfAll
    {
      public string ENumber { get; set; }
    }
}
