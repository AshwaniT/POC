﻿using System.ServiceModel;

namespace ServiceAndContract
{
    [ServiceContract]
    public interface IMyService
    {
        [OperationContract]
        string GetMessage();

        [ServiceKnownType(typeof (DerivedOne))]
        [ServiceKnownType(typeof (DerviedTwo))]
        [OperationContract]
        [TransactionFlow(TransactionFlowOption.Allowed)]
        bool DoProcessing(BaseOfAll all);

    }
}
