﻿
using System.Runtime.Serialization;

namespace ServiceAndContract
{
     [DataContract]
   public class DerviedTwo: BaseOfAll
    {
       public  string Message { get; set; }
    }
}
