﻿
using System;
using System.ServiceModel;
using System.Transactions;

namespace ServiceAndContract
{
   public class MyService: IMyService
    {
        public string GetMessage()
        {
            return "hello";
        }

        [OperationBehavior(TransactionScopeRequired = true)]
        public bool DoProcessing(BaseOfAll all)
        {
            using (TransactionScope ts = new TransactionScope(TransactionScopeOption.Required))
            {
                try
                {

                    // Call your webservice transactions here
                    ts.Complete();
                }
                catch (Exception ex)
                {
                    ts.Dispose();
                    
                }
            }
            return false;
        }
    }
}
