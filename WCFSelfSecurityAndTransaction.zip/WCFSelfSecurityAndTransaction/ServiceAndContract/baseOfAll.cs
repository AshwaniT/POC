﻿
using System.ServiceModel;
using System.Runtime.Serialization;

namespace ServiceAndContract
{
    [DataContract]
   public  class BaseOfAll
    {
       public string Name { get; set; }
    }
}
