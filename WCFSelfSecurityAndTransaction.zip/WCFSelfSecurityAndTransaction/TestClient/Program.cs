﻿
using System;
using ServiceAndContract;

namespace TestClient
{
  public  class Program
    {
        static void Main(string[] args)
        {
            var arr = new BaseOfAll[2];
            arr[0]=new DerivedOne();
            arr[1]=new DerviedTwo();
            foreach (var baseOfAll in arr)
            {
               // Method1(baseOfAll);
            }
        }

      public static void Method1(DerivedOne d)
      {
          Console.WriteLine("one");
      }

      public static void Method1(DerviedTwo d)
      {
          Console.WriteLine("two");
      }

    }
}
