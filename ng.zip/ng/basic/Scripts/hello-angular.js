﻿
var indexController = function($scope) {
    $scope.tweets = [
        { screenName: "Sumit", tweetText: "Test 1" },
        { screenName: "Sumit", tweetText: "Test 2" }];
}

